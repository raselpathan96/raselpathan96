package shape;

public class Sphere extends Shape {


}