import java.util.Map;

public class Team {

    private String name;
    private Map<String, String> players;

    public Team(String name) {
        // TODO
    }
    
    public String getName() {
        // TODO
        return null;
    }

    public void setName(String name) {
        // TODO
    }

    public String getPlayer(String position) {
        // TODO
        return null;
    }

    public void setPlayer(String position, String player) {
        // TODO
    }    

    
}
