package service;


public interface AccountService {

    
}