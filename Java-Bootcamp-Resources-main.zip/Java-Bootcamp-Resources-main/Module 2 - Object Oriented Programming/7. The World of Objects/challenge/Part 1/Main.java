public class Main {
    
    public static void main(String[] args) {
        Movie[] movies = new Movie[] {
            
        };

        System.out.println("********************************MOVIE STORE*******************************");
        for (int i = 0; i < movies.length; i++) {
            System.out.println(movies[i]);
        }

    }


}
