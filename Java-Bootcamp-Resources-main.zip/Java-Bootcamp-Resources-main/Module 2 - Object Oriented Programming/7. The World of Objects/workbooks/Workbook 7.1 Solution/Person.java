public class Person {
    
    String name;
    String nationality;
    String dateOfBirth;
    String[] passport;
    int seatNumber;
 
}
