public class ExampleTwo {
    public static void main(String[] args) {

    }
    
    public static void readFile(String fileName) {
        // FileInputStream fis = new FileInputStream("greetings.txt");
        // Scanner scanner = new Scanner(fis);
        // System.out.println(scanner.nextLine());
        // scanner.close();
    }
}