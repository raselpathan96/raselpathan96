public class FizzBuzz {
    public static void main(String[] args) {

        // See Learn the Part for detailed instructions.

    }

}
